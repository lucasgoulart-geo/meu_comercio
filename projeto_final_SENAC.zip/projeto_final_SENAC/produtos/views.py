from django.shortcuts import render
from .models import Produto, home

def home(request):
    return render (request, 'produtos/index.html')

def lista_produtos(request):
    produtos = Produto.objects.all()
    return render(request, 'produtos/lista_produtos.html', {'produtos': produtos})
# Create your views here.
