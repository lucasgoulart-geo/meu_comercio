from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # rota principal
    path('produtos/', views.lista_produtos, name='lista_produtos'),  # rota para lista de produtos
]